public class PerformanceTester {
    public void performTask() throws InterruptedException {
        // Simulate some task
        Thread.sleep(100); // 100 ms delay
    }
}
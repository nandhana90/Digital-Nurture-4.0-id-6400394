import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class OrderedTests {

    @Test
    @Order(1)
    void testOne() {
        System.out.println("Test 1");
        assertTrue(true);
    }

    @Test
    @Order(2)
    void testTwo() {
        System.out.println("Test 2");
        assertTrue(true);
    }

    @Test
    @Order(3)
    void testThree() {
        System.out.println("Test 3");
        assertTrue(true);
    }
}